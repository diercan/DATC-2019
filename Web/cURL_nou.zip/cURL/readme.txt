META:

When refering to:

-H 'Content-Type: application/json' needed for all POST methods

Data - Files from S3
Info - Data in table, specifically 'Candidati' table
Voters - Data from 'Votanti' table

S3 - cloud storage (something like Google Drive)
DynamoDB - DataBase with all tables

