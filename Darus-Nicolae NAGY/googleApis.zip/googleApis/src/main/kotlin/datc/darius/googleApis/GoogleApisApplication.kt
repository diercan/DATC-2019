package datc.darius.googleApis

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class GoogleApisApplication

fun main(args: Array<String>) {
	runApplication<GoogleApisApplication>(*args)
}
